Cufon.replace('#menu a, .banner strong, .banner b, h2, h3', { fontFamily: 'Forum', hover:true });

